from graphviz import Digraph


dot = Digraph(comment='Network Topology', engine='circo')

def draw_graph(dot,router_data):
    
    nodes_added = dict() 
    links_added = set()
    
    for entry in router_data:
        local = entry['lldp_local_system_name']
        local_ip = entry['lldp_local_management_address']
        neighbor = entry['lldp_remote_system_name']
        neighbor_ip = entry['ldp_remote_management_address']
        local_intf = entry['lldp_local_interface']
        neighbor_intf = entry['lldp_remote_port_description']
    
    
        if local not in nodes_added:
            dot.node(local, label=f"{local}\n{local_ip}")
            nodes_added[local] = local_ip
    
        if neighbor not in nodes_added:
            dot.node(neighbor, label=f"{neighbor}\n{neighbor_ip}")
            nodes_added[neighbor] = neighbor_ip
    
    
        link_key = tuple(sorted([local, neighbor]))
        if link_key not in links_added:
            label = f"{local_intf} <--> {neighbor_intf}"
            dot.edge(local, neighbor, label=label)
            links_added.add(link_key)
    return dot


dot = draw_graph(dot, router_data)
dot.render('network_topology.gv', view=True)
