from jnpr.junos import Device
from jnpr.junos.exception import ConnectError, CommitError
from jnpr.junos.utils.config import Config


devices = ["192.168.1.35", "192.168.1.36","192.168.1.37","192.168.1.38","192.168.1.39","192.168.1.13","192.168.1.14"]

interfaces = ['ge-0/0/1','ge-0/0/2','ge-0/0/3','lo0']
for dev in devices:
    try:
        with Device(host=dev, user="labuser", password="Labuser") as device:
            device.bind(conf=Config)
            device.conf.load("delete protocols ospf")
            for interface in interfaces:
                device.conf.load(f"delete security zones security-zone trust interfaces {interface}")
                device.conf.load(f"delete interfaces {interface}")               
            success = device.conf.commit()
            print('Success = {0}'.format(success))
    except ConnectError as err:
        print("\nCannot connect to device: {0}".format(err))
    except CommitError as err:
        print("\nCommit error: " + repr(err))
    except Exception as err:
        print(repr(err))
