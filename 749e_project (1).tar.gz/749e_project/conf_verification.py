from jnpr.junos.device import Device
from jnpr.junos.exception import ConnectError
routers = [
    {
        "host_name": "RouterA",
        "mgnt_ip": "35.212.26.240",
        "mgnt_port": "5002",
    },
    {
        "host_name": "RouterB",
        "mgnt_ip": "35.212.26.240",
        "mgnt_port": "5004",
    },
    {
        "host_name": "RouterC",
        "mgnt_ip": "35.212.26.240",
        "mgnt_port": "5006",
    },
    {
        "host_name": "RouterD",
        "mgnt_ip": "35.212.26.240",
        "mgnt_port": "5000",
    }
]

interfaces = [
    {
        "host_name": "RouterA",
        'if_ips': {
            'ge-0/0/1': "72.114.96.1",
            'ge-0/0/2': "72.114.96.5",
            # 'ge-0/0/3': "72.114.97.1",
            'lo0': "72.114.96.16"
            }
    },
    {
        "host_name": "RouterB",
        'if_ips': {
            'ge-0/0/1': "72.114.96.2",
            'ge-0/0/2': "72.114.96.14",
            # 'ge-0/0/3': "72.114.98.1",
            'lo0': "72.114.96.17",
            }
    },
    {
        "host_name": "RouterC",
        'if_ips': {
            'ge-0/0/1': "72.114.96.10",
            # 'ge-0/0/2': "72.114.99.1/25",
            'ge-0/0/3': "72.114.96.13",
            'lo0': "72.114.96.18"
            }
    },
    {
        "host_name": "RouterD",
        'if_ips': {
            # 'ge-0/0/1': "72.114.100.1",
            'ge-0/0/2': "72.114.96.9",
            'ge-0/0/3': "72.114.96.6",
            'lo0': "72.114.96.19"
            }
    }
]
loopback_addr = ["72.114.96.16/32", "72.114.96.17/32", "72.114.96.18/32", "72.114.96.19/32"]

for router in routers:
    try: 
        with Device (host=router['mgnt_ip'], port=router["mgnt_port"], mode="telnet", user="labuser", password="Labuser") as device:
            # Pinging all connected interfaces
            for interface in interfaces:
                if interface['host_name'] == router["host_name"]:
                    pass
                else:
                    for if_ip_name, if_ip_addr in interface['if_ips'].items():
                        if if_ip_name != "lo0":
                            response = device.rpc.ping(host=if_ip_addr, count="3")
                            if response.xpath("ping-failure"):
                                print(f"{router["host_name"]} pinging {if_ip_name} of {interface['host_name']} failed")
                            elif response.xpath("ping-success"):
                                print(f"{router["host_name"]} pinging {if_ip_name} of {interface['host_name']} succeeded")
            
            # Retrieve the content if the route table
            response = device.rpc.get_route_information()
            ips = []
            for route in response.xpath('route-table/rt'):
                if route[1][3].text == "OSPF":
                    ips.append(route[0].text)
            remote_loopback_ips = [loopback_ip for loopback_ip in ips if loopback_ip in loopback_addr]
            if len(remote_loopback_ips) == 3:
                print(f"All remote loopback present in {router["host_name"]}")
            else:
                print("Some loopback ip address are not present")
            
            # Pinging all remote loopback interfaces
            for interface in interfaces:
                if interface['host_name'] == router["host_name"]:
                    pass
                else:
                    for if_ip_name, if_ip_addr in interface['if_ips'].items():
                        if if_ip_name == "lo0":
                            response = device.rpc.ping(host=if_ip_addr, count="3")
                            if response.xpath("ping-failure"):
                                print(f"{router["host_name"]} pinging {if_ip_name} of {interface['host_name']} failed")
                            elif response.xpath("ping-success"):
                                print(f"{router["host_name"]} pinging {if_ip_name} of {interface['host_name']} succeeded")

    except ConnectError as err:
        print("Cannot connect to device: {0}".format(repr(err)))
    except Exception as err:
        print(repr(err))